(function(define){var __define; typeof define === "function" && (__define=define,define=null);
import {Storage as $loClm$Storage} from "@plasmohq/storage";


const $6d6185a15d0c9c51$export$e506a1d27d1eaa20 = {
    matches: [
        "<all_urls>"
    ]
};
const $6d6185a15d0c9c51$var$storage = new (0, $loClm$Storage)();
const $6d6185a15d0c9c51$var$overlay = document.createElement("div");
$6d6185a15d0c9c51$var$overlay.id = "element-spotter-overlay";
Object.assign($6d6185a15d0c9c51$var$overlay.style, {
    position: "fixed",
    pointerEvents: "none",
    zIndex: "2147483647",
    border: "2px solid #3b82f6",
    backgroundColor: "rgba(59, 130, 246, 0.2)",
    transition: "all 0.1s ease-out",
    display: "none",
    borderRadius: "2px"
});
if (document.body) document.body.appendChild($6d6185a15d0c9c51$var$overlay);
else document.addEventListener("DOMContentLoaded", ()=>{
    document.body.appendChild($6d6185a15d0c9c51$var$overlay);
});
let $6d6185a15d0c9c51$var$activeElement = null;
let $6d6185a15d0c9c51$var$isSpottingActive = true;
let $6d6185a15d0c9c51$var$currentColor = "#3b82f6";
let $6d6185a15d0c9c51$var$activeHotkey = "Alt";
let $6d6185a15d0c9c51$var$runMode = "specific";
let $6d6185a15d0c9c51$var$siteList = [];
let $6d6185a15d0c9c51$var$isDomainAllowed = true;
function $6d6185a15d0c9c51$var$updateDomainCheck() {
    const currentDomain = window.location.hostname;
    if ($6d6185a15d0c9c51$var$runMode === "all") $6d6185a15d0c9c51$var$isDomainAllowed = !$6d6185a15d0c9c51$var$siteList.includes(currentDomain);
    else $6d6185a15d0c9c51$var$isDomainAllowed = $6d6185a15d0c9c51$var$siteList.includes(currentDomain);
    if (!$6d6185a15d0c9c51$var$isDomainAllowed) $6d6185a15d0c9c51$var$updateOverlay(null);
}
$6d6185a15d0c9c51$var$storage.watch({
    isSpottingActive: (c)=>{
        $6d6185a15d0c9c51$var$isSpottingActive = c.newValue !== undefined ? c.newValue : true;
        if (!$6d6185a15d0c9c51$var$isSpottingActive) $6d6185a15d0c9c51$var$updateOverlay(null);
    },
    highlightColor: (c)=>{
        if (c.newValue) {
            $6d6185a15d0c9c51$var$currentColor = c.newValue;
            $6d6185a15d0c9c51$var$overlay.style.borderColor = $6d6185a15d0c9c51$var$currentColor;
            const r = parseInt($6d6185a15d0c9c51$var$currentColor.slice(1, 3), 16);
            const g = parseInt($6d6185a15d0c9c51$var$currentColor.slice(3, 5), 16);
            const b = parseInt($6d6185a15d0c9c51$var$currentColor.slice(5, 7), 16);
            $6d6185a15d0c9c51$var$overlay.style.backgroundColor = `rgba(${r}, ${g}, ${b}, 0.2)`;
        }
    },
    hotkey: (c)=>{
        if (c.newValue) {
            $6d6185a15d0c9c51$var$activeHotkey = c.newValue;
            $6d6185a15d0c9c51$var$isCtrlPressed = false;
            $6d6185a15d0c9c51$var$updateOverlay(null);
        }
    },
    runMode: (c)=>{
        if (c.newValue) {
            $6d6185a15d0c9c51$var$runMode = c.newValue;
            $6d6185a15d0c9c51$var$updateDomainCheck();
        }
    },
    siteList: (c)=>{
        if (c.newValue) {
            $6d6185a15d0c9c51$var$siteList = c.newValue;
            $6d6185a15d0c9c51$var$updateDomainCheck();
        }
    }
});
Promise.all([
    $6d6185a15d0c9c51$var$storage.get("runMode"),
    $6d6185a15d0c9c51$var$storage.get("siteList"),
    $6d6185a15d0c9c51$var$storage.get("isSpottingActive"),
    $6d6185a15d0c9c51$var$storage.get("highlightColor"),
    $6d6185a15d0c9c51$var$storage.get("hotkey")
]).then(([m, l, active, color, hk])=>{
    if (m !== undefined) $6d6185a15d0c9c51$var$runMode = m;
    if (l !== undefined) $6d6185a15d0c9c51$var$siteList = l;
    if (active !== undefined) $6d6185a15d0c9c51$var$isSpottingActive = active;
    if (color !== undefined) {
        const colorStr = color;
        if (/^#[0-9a-fA-F]{6}$/.test(colorStr)) {
            $6d6185a15d0c9c51$var$currentColor = colorStr;
            $6d6185a15d0c9c51$var$overlay.style.borderColor = $6d6185a15d0c9c51$var$currentColor;
            const r = parseInt($6d6185a15d0c9c51$var$currentColor.slice(1, 3), 16);
            const g = parseInt($6d6185a15d0c9c51$var$currentColor.slice(3, 5), 16);
            const b = parseInt($6d6185a15d0c9c51$var$currentColor.slice(5, 7), 16);
            $6d6185a15d0c9c51$var$overlay.style.backgroundColor = `rgba(${r}, ${g}, ${b}, 0.2)`;
        }
    }
    if (hk !== undefined) $6d6185a15d0c9c51$var$activeHotkey = hk;
    $6d6185a15d0c9c51$var$updateDomainCheck();
});
let $6d6185a15d0c9c51$var$isCtrlPressed = false;
function $6d6185a15d0c9c51$var$updateOverlay(el) {
    if (!el || !$6d6185a15d0c9c51$var$isSpottingActive || !$6d6185a15d0c9c51$var$isCtrlPressed || !$6d6185a15d0c9c51$var$isDomainAllowed) {
        $6d6185a15d0c9c51$var$overlay.style.display = "none";
        return;
    }
    const rect = el.getBoundingClientRect();
    Object.assign($6d6185a15d0c9c51$var$overlay.style, {
        display: "block",
        top: `${rect.top}px`,
        left: `${rect.left}px`,
        width: `${rect.width}px`,
        height: `${rect.height}px`
    });
}
window.addEventListener("keydown", (e)=>{
    if (e.key === $6d6185a15d0c9c51$var$activeHotkey) {
        e.preventDefault();
        $6d6185a15d0c9c51$var$isCtrlPressed = true;
        if ($6d6185a15d0c9c51$var$isSpottingActive && $6d6185a15d0c9c51$var$activeElement) $6d6185a15d0c9c51$var$updateOverlay($6d6185a15d0c9c51$var$activeElement);
    }
}, true);
window.addEventListener("keyup", (e)=>{
    if (e.key === $6d6185a15d0c9c51$var$activeHotkey) {
        $6d6185a15d0c9c51$var$isCtrlPressed = false;
        $6d6185a15d0c9c51$var$updateOverlay(null);
    }
}, true);
window.addEventListener("mouseover", (e)=>{
    if (!$6d6185a15d0c9c51$var$isSpottingActive) return;
    const target = e.target;
    if (target === document.body || target === document.documentElement) return;
    $6d6185a15d0c9c51$var$activeElement = target;
    $6d6185a15d0c9c51$var$updateOverlay($6d6185a15d0c9c51$var$activeElement);
}, true);
window.addEventListener("scroll", ()=>$6d6185a15d0c9c51$var$updateOverlay($6d6185a15d0c9c51$var$activeElement), true);
window.addEventListener("resize", ()=>$6d6185a15d0c9c51$var$updateOverlay($6d6185a15d0c9c51$var$activeElement), true);
let $6d6185a15d0c9c51$var$isCapturing = false;
window.addEventListener("click", async (e)=>{
    if (!$6d6185a15d0c9c51$var$isSpottingActive || !$6d6185a15d0c9c51$var$activeElement || !$6d6185a15d0c9c51$var$isCtrlPressed || !$6d6185a15d0c9c51$var$isDomainAllowed || e.button !== 0 || $6d6185a15d0c9c51$var$isCapturing) return;
    e.preventDefault();
    e.stopPropagation();
    $6d6185a15d0c9c51$var$isCapturing = true;
    try {
        const htmlText = $6d6185a15d0c9c51$var$activeElement.outerHTML;
        try {
            await navigator.clipboard.writeText(htmlText);
        } catch (err) {
            console.warn("Failed to copy to clipboard", err);
            $6d6185a15d0c9c51$var$isCapturing = false;
            return;
        }
        $6d6185a15d0c9c51$var$overlay.style.backgroundColor = "rgba(34, 197, 94, 0.5)";
        $6d6185a15d0c9c51$var$overlay.style.borderColor = "#22c55e";
        const floatText = document.createElement("div");
        floatText.innerText = "COPIED!";
        Object.assign(floatText.style, {
            position: "fixed",
            left: `${e.clientX}px`,
            top: `${e.clientY - 20}px`,
            transform: "translate(-50%, -50%)",
            backgroundColor: "#22c55e",
            color: "#fff",
            border: "2px solid #000",
            boxShadow: "4px 4px 0 0 #000",
            padding: "4px 8px",
            fontFamily: "monospace",
            fontWeight: "bold",
            fontSize: "14px",
            zIndex: "2147483647",
            pointerEvents: "none",
            transition: "all 1s ease-out",
            opacity: "1"
        });
        document.body.appendChild(floatText);
        // Animate float up and fade out in the next tick
        setTimeout(()=>{
            floatText.style.top = `${e.clientY - 60}px`;
            floatText.style.opacity = "0";
        }, 10);
        // Reset everything after animation finishes
        setTimeout(()=>{
            // Remove floating text
            if (floatText.parentNode) document.body.removeChild(floatText);
            // Reset overlay to current user color
            if ($6d6185a15d0c9c51$var$currentColor) {
                $6d6185a15d0c9c51$var$overlay.style.borderColor = $6d6185a15d0c9c51$var$currentColor;
                const r = parseInt($6d6185a15d0c9c51$var$currentColor.slice(1, 3), 16);
                const g = parseInt($6d6185a15d0c9c51$var$currentColor.slice(3, 5), 16);
                const b = parseInt($6d6185a15d0c9c51$var$currentColor.slice(5, 7), 16);
                if (!isNaN(r) && !isNaN(g) && !isNaN(b)) $6d6185a15d0c9c51$var$overlay.style.backgroundColor = `rgba(${r}, ${g}, ${b}, 0.2)`;
            }
        }, 1000);
    } finally{
        // Ensure capturing lock is released after animation time even if errors occur
        setTimeout(()=>{
            $6d6185a15d0c9c51$var$isCapturing = false;
        }, 1000);
    }
}, true);
window.addEventListener("mouseout", (e)=>{
    if (!$6d6185a15d0c9c51$var$isSpottingActive) return;
    if (!e.relatedTarget) {
        $6d6185a15d0c9c51$var$activeElement = null;
        $6d6185a15d0c9c51$var$updateOverlay(null);
    }
}, true);


export {$6d6185a15d0c9c51$export$e506a1d27d1eaa20 as config};
 globalThis.define=__define;  })(globalThis.define);