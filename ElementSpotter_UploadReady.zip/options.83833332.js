(function(define){var __define; typeof define === "function" && (__define=define,define=null);
import "./popup.9ec4b067.css";
import {jsx as $96OZm$jsx, jsxs as $96OZm$jsxs} from "react/jsx-runtime";
import {Fragment as $96OZm$Fragment, useState as $96OZm$useState} from "react";
import {createRoot as $96OZm$createRoot} from "react-dom/client";
import {useStorage as $96OZm$useStorage} from "@plasmohq/storage/hook";

function $parcel$defineInteropFlag(a) {
  Object.defineProperty(a, '__esModule', {value: true, configurable: true});
}
function $parcel$export(e, n, v, s) {
  Object.defineProperty(e, n, {get: v, set: s, enumerable: true, configurable: true});
}




const $0b3ccfbeb4084da1$export$15b332947189bc50 = (RawImport)=>typeof RawImport.Layout === "function" ? RawImport.Layout : typeof RawImport.getGlobalProvider === "function" ? RawImport.getGlobalProvider() : (0, $96OZm$Fragment);


var $ac4c1d7e3ad1d416$exports = {};

$parcel$defineInteropFlag($ac4c1d7e3ad1d416$exports);

$parcel$export($ac4c1d7e3ad1d416$exports, "default", () => $ac4c1d7e3ad1d416$export$2e2bcd8739ae039);




const $ac4c1d7e3ad1d416$var$CheckIcon = ()=>/*#__PURE__*/ (0, $96OZm$jsx)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "3",
        className: "text-slate-900",
        children: /*#__PURE__*/ (0, $96OZm$jsx)("polyline", {
            points: "20 6 9 17 4 12"
        })
    });
function $ac4c1d7e3ad1d416$var$IndexOptions() {
    const [highlightColor, setHighlightColor] = (0, $96OZm$useStorage)("highlightColor", "#3b82f6");
    const [runMode, setRunMode] = (0, $96OZm$useStorage)("runMode", "specific");
    const [siteList, setSiteList] = (0, $96OZm$useStorage)("siteList", []);
    const [newSite, setNewSite] = (0, $96OZm$useState)("");
    const colors = [
        "#ef4444",
        "#3b82f6",
        "#22c55e",
        "#eab308",
        "#a855f7"
    ];
    const handleAddSite = (e)=>{
        e.preventDefault();
        const site = newSite.trim().toLowerCase();
        if (site && !siteList.includes(site)) {
            setSiteList([
                ...siteList,
                site
            ]);
            setNewSite("");
        }
    };
    const handleRemoveSite = (site)=>{
        setSiteList(siteList.filter((s)=>s !== site));
    };
    return /*#__PURE__*/ (0, $96OZm$jsx)("div", {
        className: "min-h-screen bg-white text-slate-900 p-8 font-mono",
        children: /*#__PURE__*/ (0, $96OZm$jsxs)("div", {
            className: "max-w-3xl mx-auto bg-white border-4 border-slate-900 shadow-[8px_8px_0_0_#0f172a]",
            children: [
                /*#__PURE__*/ (0, $96OZm$jsxs)("div", {
                    className: "border-b-4 border-slate-900 p-6 bg-yellow-400",
                    children: [
                        /*#__PURE__*/ (0, $96OZm$jsx)("h1", {
                            className: "text-3xl font-black uppercase tracking-tighter",
                            children: "ElementSpotter Settings"
                        }),
                        /*#__PURE__*/ (0, $96OZm$jsx)("p", {
                            className: "font-bold mt-2",
                            children: "STRICT DEVELOPER CONFIGURATION"
                        })
                    ]
                }),
                /*#__PURE__*/ (0, $96OZm$jsxs)("div", {
                    className: "p-6 space-y-12",
                    children: [
                        /*#__PURE__*/ (0, $96OZm$jsxs)("section", {
                            children: [
                                /*#__PURE__*/ (0, $96OZm$jsx)("h3", {
                                    className: "text-xl font-black uppercase mb-4 border-b-2 border-slate-900 pb-2",
                                    children: "Highlight Color"
                                }),
                                /*#__PURE__*/ (0, $96OZm$jsx)("div", {
                                    className: "flex gap-4",
                                    children: colors.map((color)=>/*#__PURE__*/ (0, $96OZm$jsx)("button", {
                                            onClick: ()=>setHighlightColor(color),
                                            className: `w-12 h-12 flex items-center justify-center border-4 border-slate-900 transition-transform hover:-translate-y-1 hover:translate-x-1 ${highlightColor === color ? "shadow-[4px_4px_0_0_#0f172a]" : ""}`,
                                            style: {
                                                backgroundColor: color
                                            },
                                            title: `Select color ${color}`,
                                            children: highlightColor === color && /*#__PURE__*/ (0, $96OZm$jsx)($ac4c1d7e3ad1d416$var$CheckIcon, {})
                                        }, color))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0, $96OZm$jsxs)("section", {
                            children: [
                                /*#__PURE__*/ (0, $96OZm$jsx)("h3", {
                                    className: "text-xl font-black uppercase mb-4 border-b-2 border-slate-900 pb-2",
                                    children: "Website Permissions"
                                }),
                                /*#__PURE__*/ (0, $96OZm$jsxs)("div", {
                                    className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8",
                                    children: [
                                        /*#__PURE__*/ (0, $96OZm$jsxs)("button", {
                                            onClick: ()=>setRunMode("all"),
                                            className: `p-4 border-4 border-slate-900 text-left transition-all ${runMode === "all" ? "bg-slate-900 text-white shadow-[4px_4px_0_0_#ef4444]" : "bg-white hover:bg-slate-100 hover:-translate-y-1 hover:translate-x-1 shadow-[4px_4px_0_0_#0f172a]"}`,
                                            children: [
                                                /*#__PURE__*/ (0, $96OZm$jsx)("h4", {
                                                    className: "font-black text-xl uppercase mb-2",
                                                    children: "Global Mode"
                                                }),
                                                /*#__PURE__*/ (0, $96OZm$jsx)("p", {
                                                    className: `font-bold ${runMode === "all" ? "text-slate-300" : "text-slate-600"}`,
                                                    children: "Run everywhere. Use list below as BLACKLIST."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0, $96OZm$jsxs)("button", {
                                            onClick: ()=>setRunMode("specific"),
                                            className: `p-4 border-4 border-slate-900 text-left transition-all ${runMode === "specific" ? "bg-slate-900 text-white shadow-[4px_4px_0_0_#22c55e]" : "bg-white hover:bg-slate-100 hover:-translate-y-1 hover:translate-x-1 shadow-[4px_4px_0_0_#0f172a]"}`,
                                            children: [
                                                /*#__PURE__*/ (0, $96OZm$jsx)("h4", {
                                                    className: "font-black text-xl uppercase mb-2",
                                                    children: "Specific Mode"
                                                }),
                                                /*#__PURE__*/ (0, $96OZm$jsx)("p", {
                                                    className: `font-bold ${runMode === "specific" ? "text-slate-300" : "text-slate-600"}`,
                                                    children: "Disabled default. Use list below as WHITELIST."
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0, $96OZm$jsxs)("div", {
                                    className: "bg-slate-100 border-4 border-slate-900 p-6",
                                    children: [
                                        /*#__PURE__*/ (0, $96OZm$jsx)("h4", {
                                            className: "font-black uppercase mb-4 text-lg",
                                            children: runMode === "all" ? "Blacklisted Sites" : "Whitelisted Sites"
                                        }),
                                        /*#__PURE__*/ (0, $96OZm$jsxs)("form", {
                                            onSubmit: handleAddSite,
                                            className: "flex gap-4 mb-8",
                                            children: [
                                                /*#__PURE__*/ (0, $96OZm$jsx)("input", {
                                                    type: "text",
                                                    value: newSite,
                                                    onChange: (e)=>setNewSite(e.target.value),
                                                    placeholder: "e.g. google.com",
                                                    className: "flex-1 bg-white border-4 border-slate-900 px-4 py-3 font-bold placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-blue-500"
                                                }),
                                                /*#__PURE__*/ (0, $96OZm$jsx)("button", {
                                                    type: "submit",
                                                    disabled: !newSite.trim(),
                                                    className: "px-6 py-3 bg-blue-500 hover:bg-blue-600 text-slate-900 font-black uppercase border-4 border-slate-900 disabled:opacity-50 transition-transform active:translate-y-1 active:translate-x-1",
                                                    children: "Add Site"
                                                })
                                            ]
                                        }),
                                        siteList.length === 0 ? /*#__PURE__*/ (0, $96OZm$jsx)("div", {
                                            className: "border-4 border-dashed border-slate-400 p-8 text-center font-bold text-slate-500 uppercase",
                                            children: "No websites added"
                                        }) : /*#__PURE__*/ (0, $96OZm$jsx)("ul", {
                                            className: "space-y-4",
                                            children: siteList.map((site)=>/*#__PURE__*/ (0, $96OZm$jsxs)("li", {
                                                    className: "flex items-center justify-between bg-white border-4 border-slate-900 p-4 shadow-[4px_4px_0_0_#0f172a]",
                                                    children: [
                                                        /*#__PURE__*/ (0, $96OZm$jsx)("span", {
                                                            className: "font-black text-lg",
                                                            children: site
                                                        }),
                                                        /*#__PURE__*/ (0, $96OZm$jsx)("button", {
                                                            onClick: ()=>handleRemoveSite(site),
                                                            className: "bg-red-500 hover:bg-red-600 text-slate-900 font-black border-2 border-slate-900 px-3 py-1 uppercase text-sm",
                                                            title: "Remove website",
                                                            children: "REMOVE"
                                                        })
                                                    ]
                                                }, site))
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}
var $ac4c1d7e3ad1d416$export$2e2bcd8739ae039 = $ac4c1d7e3ad1d416$var$IndexOptions;


let $981a862b4392bbb4$var$__plasmoRoot = null;
document.addEventListener("DOMContentLoaded", ()=>{
    if (!!$981a862b4392bbb4$var$__plasmoRoot) return;
    $981a862b4392bbb4$var$__plasmoRoot = document.getElementById("__plasmo");
    const root = (0, $96OZm$createRoot)($981a862b4392bbb4$var$__plasmoRoot);
    const Layout = (0, $0b3ccfbeb4084da1$export$15b332947189bc50)($ac4c1d7e3ad1d416$exports);
    root.render(/*#__PURE__*/ (0, $96OZm$jsx)(Layout, {
        children: /*#__PURE__*/ (0, $96OZm$jsx)($ac4c1d7e3ad1d416$exports.default, {})
    }));
});


 globalThis.define=__define;  })(globalThis.define);