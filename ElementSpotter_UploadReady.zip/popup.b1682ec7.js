(function(define){var __define; typeof define === "function" && (__define=define,define=null);
import "./popup.9ec4b067.css";
import {jsx as $9u1QC$jsx, jsxs as $9u1QC$jsxs} from "react/jsx-runtime";
import {Fragment as $9u1QC$Fragment, useState as $9u1QC$useState, useEffect as $9u1QC$useEffect} from "react";
import {createRoot as $9u1QC$createRoot} from "react-dom/client";
import {useStorage as $9u1QC$useStorage} from "@plasmohq/storage/hook";

function $parcel$defineInteropFlag(a) {
  Object.defineProperty(a, '__esModule', {value: true, configurable: true});
}
function $parcel$export(e, n, v, s) {
  Object.defineProperty(e, n, {get: v, set: s, enumerable: true, configurable: true});
}




const $0b3ccfbeb4084da1$export$15b332947189bc50 = (RawImport)=>typeof RawImport.Layout === "function" ? RawImport.Layout : typeof RawImport.getGlobalProvider === "function" ? RawImport.getGlobalProvider() : (0, $9u1QC$Fragment);


var $6553fee709e6a081$exports = {};

$parcel$defineInteropFlag($6553fee709e6a081$exports);

$parcel$export($6553fee709e6a081$exports, "default", () => $6553fee709e6a081$export$2e2bcd8739ae039);




const $6553fee709e6a081$var$CustomCrosshair = ()=>/*#__PURE__*/ (0, $9u1QC$jsxs)("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        className: "text-slate-900",
        children: [
            /*#__PURE__*/ (0, $9u1QC$jsx)("rect", {
                x: "3",
                y: "3",
                width: "18",
                height: "18"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("line", {
                x1: "12",
                y1: "3",
                x2: "12",
                y2: "21"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("line", {
                x1: "3",
                y1: "12",
                x2: "21",
                y2: "12"
            })
        ]
    });
const $6553fee709e6a081$var$CustomGithub = ()=>/*#__PURE__*/ (0, $9u1QC$jsxs)("svg", {
        width: "14",
        height: "14",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        children: [
            /*#__PURE__*/ (0, $9u1QC$jsx)("rect", {
                x: "2",
                y: "4",
                width: "20",
                height: "16"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("path", {
                d: "M10 9L6 12L10 15"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("path", {
                d: "M14 9L18 12L14 15"
            })
        ]
    });
const $6553fee709e6a081$var$CustomDiscord = ()=>/*#__PURE__*/ (0, $9u1QC$jsxs)("svg", {
        width: "14",
        height: "14",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        children: [
            /*#__PURE__*/ (0, $9u1QC$jsx)("rect", {
                x: "2",
                y: "4",
                width: "20",
                height: "12"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("rect", {
                x: "7",
                y: "8",
                width: "2",
                height: "2",
                fill: "currentColor",
                stroke: "none"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("rect", {
                x: "15",
                y: "8",
                width: "2",
                height: "2",
                fill: "currentColor",
                stroke: "none"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("path", {
                d: "M6 16v4l4-4",
                fill: "currentColor"
            })
        ]
    });
const $6553fee709e6a081$var$CustomBug = ()=>/*#__PURE__*/ (0, $9u1QC$jsxs)("svg", {
        width: "14",
        height: "14",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        children: [
            /*#__PURE__*/ (0, $9u1QC$jsx)("rect", {
                x: "8",
                y: "4",
                width: "8",
                height: "16"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("line", {
                x1: "4",
                y1: "8",
                x2: "8",
                y2: "8"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("line", {
                x1: "4",
                y1: "16",
                x2: "8",
                y2: "16"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("line", {
                x1: "16",
                y1: "8",
                x2: "20",
                y2: "8"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("line", {
                x1: "16",
                y1: "16",
                x2: "20",
                y2: "16"
            }),
            /*#__PURE__*/ (0, $9u1QC$jsx)("line", {
                x1: "12",
                y1: "4",
                x2: "12",
                y2: "20"
            })
        ]
    });
function $6553fee709e6a081$var$IndexPopup() {
    const [isActive, setIsActive] = (0, $9u1QC$useStorage)("isSpottingActive", true);
    const [highlightColor, setHighlightColor] = (0, $9u1QC$useStorage)("highlightColor", "#3b82f6");
    const colors = [
        {
            name: "Blue",
            value: "#3b82f6"
        },
        {
            name: "Red",
            value: "#ef4444"
        },
        {
            name: "Green",
            value: "#22c55e"
        }
    ];
    const [hotkey, setHotkey] = (0, $9u1QC$useStorage)("hotkey", "Alt");
    const [isRecordingKey, setIsRecordingKey] = (0, $9u1QC$useState)(false);
    const [runMode] = (0, $9u1QC$useStorage)("runMode", "specific");
    const [siteList, setSiteList] = (0, $9u1QC$useStorage)("siteList", []);
    const [currentDomain, setCurrentDomain] = (0, $9u1QC$useState)("");
    (0, $9u1QC$useEffect)(()=>{
        if (chrome?.tabs?.query) chrome.tabs.query({
            active: true,
            currentWindow: true
        }, (tabs)=>{
            const url = tabs[0]?.url;
            if (url && !url.startsWith("chrome://")) try {
                const domain = new URL(url).hostname;
                setCurrentDomain(domain);
            } catch (e) {
                console.error("Failed to parse URL", e);
            }
        });
    }, []);
    const isSiteEnabled = runMode === "all" ? !siteList.includes(currentDomain) : siteList.includes(currentDomain);
    const toggleCurrentSite = ()=>{
        if (!currentDomain) return;
        if (siteList.includes(currentDomain)) setSiteList(siteList.filter((d)=>d !== currentDomain));
        else setSiteList([
            ...siteList,
            currentDomain
        ]);
    };
    (0, $9u1QC$useEffect)(()=>{
        if (!isRecordingKey) return;
        const handleKeyDown = (e)=>{
            e.preventDefault();
            setHotkey(e.key);
            setIsRecordingKey(false);
        };
        window.addEventListener("keydown", handleKeyDown);
        return ()=>window.removeEventListener("keydown", handleKeyDown);
    }, [
        isRecordingKey,
        setHotkey
    ]);
    const displayKey = hotkey === "Control" ? "Ctrl" : hotkey === " " ? "Space" : hotkey;
    return /*#__PURE__*/ (0, $9u1QC$jsxs)("div", {
        className: "w-64 h-auto bg-white text-slate-900 border-2 border-slate-900 font-sans p-4",
        children: [
            /*#__PURE__*/ (0, $9u1QC$jsxs)("div", {
                className: "flex items-center gap-2 mb-6 border-b-2 border-slate-900 pb-2",
                children: [
                    /*#__PURE__*/ (0, $9u1QC$jsx)($6553fee709e6a081$var$CustomCrosshair, {}),
                    /*#__PURE__*/ (0, $9u1QC$jsx)("h1", {
                        className: "text-lg font-bold uppercase tracking-tight text-slate-900",
                        children: "ElementSpotter"
                    })
                ]
            }),
            /*#__PURE__*/ (0, $9u1QC$jsxs)("div", {
                className: "flex items-center justify-between mb-4",
                children: [
                    /*#__PURE__*/ (0, $9u1QC$jsx)("span", {
                        className: "text-sm font-bold text-slate-800 uppercase",
                        children: "Spotting"
                    }),
                    /*#__PURE__*/ (0, $9u1QC$jsx)("button", {
                        onClick: ()=>setIsActive(!(isActive ?? true)),
                        className: `relative flex items-center w-12 h-6 border-2 border-slate-900 transition-colors ${isActive ? "bg-slate-900" : "bg-slate-300"}`,
                        children: /*#__PURE__*/ (0, $9u1QC$jsx)("div", {
                            className: `w-5 h-5 bg-white border-2 border-slate-900 transition-transform ${isActive ? "translate-x-6" : "translate-x-0"}`
                        })
                    })
                ]
            }),
            currentDomain && /*#__PURE__*/ (0, $9u1QC$jsxs)("div", {
                className: "flex items-center justify-between mb-6 pb-4 border-b-2 border-slate-900 border-dashed",
                children: [
                    /*#__PURE__*/ (0, $9u1QC$jsxs)("span", {
                        className: "text-xs font-bold text-slate-800 truncate pr-2",
                        title: currentDomain,
                        children: [
                            "Run on ",
                            currentDomain
                        ]
                    }),
                    /*#__PURE__*/ (0, $9u1QC$jsx)("button", {
                        onClick: toggleCurrentSite,
                        className: `px-2 py-0.5 border-2 border-slate-900 text-[10px] font-bold uppercase transition-colors ${isSiteEnabled ? "bg-green-500 text-white" : "bg-slate-200 text-slate-500"}`,
                        children: isSiteEnabled ? "ON" : "OFF"
                    })
                ]
            }),
            /*#__PURE__*/ (0, $9u1QC$jsxs)("div", {
                className: "mb-6",
                children: [
                    /*#__PURE__*/ (0, $9u1QC$jsx)("span", {
                        className: "block text-sm font-bold text-slate-800 uppercase mb-3",
                        children: "Color"
                    }),
                    /*#__PURE__*/ (0, $9u1QC$jsx)("div", {
                        className: "flex gap-3",
                        children: colors.map((color)=>/*#__PURE__*/ (0, $9u1QC$jsx)("button", {
                                onClick: ()=>setHighlightColor(color.value),
                                className: `w-8 h-8 border-2 ${highlightColor === color.value ? "border-slate-900 scale-110" : "border-slate-300 hover:border-slate-900"} transition-transform`,
                                style: {
                                    backgroundColor: color.value
                                },
                                title: color.name,
                                "aria-label": `Select ${color.name}`
                            }, color.value))
                    })
                ]
            }),
            /*#__PURE__*/ (0, $9u1QC$jsxs)("div", {
                className: "mt-4 pt-4 border-t-2 border-slate-900 flex flex-col items-center",
                children: [
                    /*#__PURE__*/ (0, $9u1QC$jsx)("span", {
                        className: "text-[10px] font-bold text-slate-600 uppercase mb-1",
                        children: "Hotkey"
                    }),
                    /*#__PURE__*/ (0, $9u1QC$jsx)("button", {
                        onClick: ()=>setIsRecordingKey(true),
                        className: `mb-3 px-3 py-1 border-2 border-slate-900 text-xs font-bold uppercase transition-colors ${isRecordingKey ? "bg-blue-600 text-white border-blue-600" : "bg-slate-100 hover:bg-slate-200 text-slate-900"}`,
                        children: isRecordingKey ? "Press any key..." : `Hold [${displayKey}] to spot`
                    }),
                    /*#__PURE__*/ (0, $9u1QC$jsxs)("div", {
                        className: "flex justify-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, $9u1QC$jsx)("a", {
                                href: "https://github.com/Azdetic/ElementSpotter",
                                target: "_blank",
                                rel: "noreferrer",
                                title: "GitHub",
                                className: "p-1.5 border-2 border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white transition-colors",
                                children: /*#__PURE__*/ (0, $9u1QC$jsx)($6553fee709e6a081$var$CustomGithub, {})
                            }),
                            /*#__PURE__*/ (0, $9u1QC$jsx)("a", {
                                href: "https://discord.gg/eNB9HAQtg5",
                                target: "_blank",
                                rel: "noreferrer",
                                title: "Discord",
                                className: "p-1.5 border-2 border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white transition-colors",
                                children: /*#__PURE__*/ (0, $9u1QC$jsx)($6553fee709e6a081$var$CustomDiscord, {})
                            }),
                            /*#__PURE__*/ (0, $9u1QC$jsx)("a", {
                                href: "https://github.com/Azdetic/ElementSpotter/issues",
                                target: "_blank",
                                rel: "noreferrer",
                                title: "Report Issue",
                                className: "p-1.5 border-2 border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white transition-colors",
                                children: /*#__PURE__*/ (0, $9u1QC$jsx)($6553fee709e6a081$var$CustomBug, {})
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
var $6553fee709e6a081$export$2e2bcd8739ae039 = $6553fee709e6a081$var$IndexPopup;


let $4910710f4fa3f6b2$var$__plasmoRoot = null;
document.addEventListener("DOMContentLoaded", ()=>{
    if (!!$4910710f4fa3f6b2$var$__plasmoRoot) return;
    $4910710f4fa3f6b2$var$__plasmoRoot = document.getElementById("__plasmo");
    const root = (0, $9u1QC$createRoot)($4910710f4fa3f6b2$var$__plasmoRoot);
    const Layout = (0, $0b3ccfbeb4084da1$export$15b332947189bc50)($6553fee709e6a081$exports);
    root.render(/*#__PURE__*/ (0, $9u1QC$jsx)(Layout, {
        children: /*#__PURE__*/ (0, $9u1QC$jsx)($6553fee709e6a081$exports.default, {})
    }));
});


 globalThis.define=__define;  })(globalThis.define);